"""Authentication, mandatory TOTP 2FA and role protection for the Flask app."""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
import sqlite3
import time
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from urllib.parse import urlparse

import pyotp
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from cryptography.fernet import Fernet, InvalidToken
from flask import (Blueprint, abort, current_app, flash, g, jsonify, redirect,
                   render_template, request, session, url_for)


auth_bp = Blueprint("auth", __name__)
_pwd = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2)
AUTH_EXEMPT_ENDPOINTS = {
    "auth.login", "auth.logout", "auth.verify_2fa", "auth.setup_2fa",
    "auth.recovery_codes", "static"
}
# Standard Staff: customer entry, product viewing and dashboard only.
STAFF_PAGE_ALLOW = {"/", "/dashboard", "/products", "/customer-details"}
STAFF_GET_API_ALLOW = {
    "/api/data", "/api/months", "/api/customers",
    "/api/customer-details", "/api/customer-details-data",
    "/api/dashboard", "/api/month-details"
}
STAFF_POST_API_ALLOW = {"/api/save-customer", "/api/detect-product-category"}


def _db_path() -> Path:
    return Path(current_app.config["AUTH_DB_PATH"])


def _connect():
    conn = sqlite3.connect(_db_path(), timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def _fernet() -> Fernet:
    secret = current_app.secret_key.encode("utf-8")
    key = base64.urlsafe_b64encode(hashlib.sha256(b"car-accessories-totp:" + secret).digest())
    return Fernet(key)


def _encrypt(value: str) -> str:
    return _fernet().encrypt(value.encode("utf-8")).decode("ascii")


def _decrypt(value: str | None) -> str | None:
    if not value:
        return None
    try:
        return _fernet().decrypt(value.encode("ascii")).decode("utf-8")
    except (InvalidToken, ValueError):
        return None


def init_auth(app, data_dir: Path):
    """Configure persistent sessions and create only the separate auth database."""
    data_dir.mkdir(parents=True, exist_ok=True)
    secret = os.environ.get("FLASK_SECRET_KEY", "").strip()
    if not secret:
        key_file = data_dir / "session_secret.key"
        if key_file.exists():
            secret = key_file.read_text(encoding="utf-8").strip()
        else:
            secret = secrets.token_urlsafe(48)
            key_file.write_text(secret, encoding="utf-8")
            try:
                os.chmod(key_file, 0o600)
            except OSError:
                pass
    app.secret_key = secret
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0").lower() in {"1", "true", "yes"},
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        AUTH_DB_PATH=str(data_dir / "users.db"),
    )
    with sqlite3.connect(app.config["AUTH_DB_PATH"]) as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin','staff')),
                active INTEGER NOT NULL DEFAULT 1,
                totp_secret_enc TEXT,
                totp_enabled INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS recovery_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                code_hash TEXT NOT NULL,
                used_at TEXT
            );
            CREATE TABLE IF NOT EXISTS login_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                identity_hash TEXT NOT NULL,
                attempted_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_attempts_identity_time
                ON login_attempts(identity_hash, attempted_at);
        """)
    app.register_blueprint(auth_bp)

    @app.before_request
    def _protect_every_existing_route():
        endpoint = request.endpoint or ""
        if endpoint in AUTH_EXEMPT_ENDPOINTS:
            return None
        if request.path.startswith("/static/"):
            return None

        user_id = session.get("user_id")
        if not user_id:
            return _unauthorized_response()
        with _connect() as conn:
            user = conn.execute(
                "SELECT id, username, role, active, totp_enabled FROM users WHERE id=?",
                (user_id,)
            ).fetchone()
        if not user or not user["active"] or not user["totp_enabled"]:
            session.clear()
            return _unauthorized_response()
        g.current_user = dict(user)

        if user["role"] == "staff" and not _staff_route_allowed():
            if request.path.startswith("/api/"):
                return jsonify(success=False, message="Your Staff account does not have permission for this action."), 403
            abort(403)

        # Same-origin check on all state-changing requests. Existing app fetch()
        # calls work without adding headers because browsers send Origin on POST/PUT/DELETE.
        if request.method not in {"GET", "HEAD", "OPTIONS"}:
            origin = request.headers.get("Origin")
            referer = request.headers.get("Referer")
            expected = request.host
            supplied = urlparse(origin).netloc if origin else (urlparse(referer).netloc if referer else "")
            if not supplied or supplied.casefold() != expected.casefold():
                if request.path.startswith("/api/"):
                    return jsonify(success=False, message="Request origin check failed. Reload the page and try again."), 403
                abort(403)
        return None

    @app.context_processor
    def _auth_template_context():
        return {"logged_in_user": getattr(g, "current_user", None)}


def _staff_route_allowed() -> bool:
    path, method = request.path, request.method
    if method == "GET" and path in STAFF_PAGE_ALLOW:
        return True
    if method == "GET" and path in STAFF_GET_API_ALLOW:
        return True
    if method == "POST" and path in STAFF_POST_API_ALLOW:
        return True
    return False


def _unauthorized_response():
    if request.path.startswith("/api/"):
        return jsonify(success=False, message="Authentication required. Please log in."), 401
    return redirect(url_for("auth.login", next=request.full_path if request.query_string else request.path))


def _csrf_token() -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


def _check_csrf() -> bool:
    supplied = request.form.get("csrf_token") or (request.get_json(silent=True) or {}).get("csrf_token")
    expected = session.get("csrf_token", "")
    return bool(supplied and expected and hmac.compare_digest(str(supplied), str(expected)))


def _rate_key(username: str) -> str:
    raw = f"{request.remote_addr or 'unknown'}|{username.casefold()}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _is_rate_limited(identity: str) -> bool:
    now = int(time.time())
    with _connect() as conn:
        conn.execute("DELETE FROM login_attempts WHERE attempted_at < ?", (now - 3600,))
        count = conn.execute(
            "SELECT COUNT(*) FROM login_attempts WHERE identity_hash=? AND attempted_at>?",
            (identity, now - 900)
        ).fetchone()[0]
    return count >= 5


def _record_failed_attempt(identity: str):
    with _connect() as conn:
        conn.execute("INSERT INTO login_attempts(identity_hash, attempted_at) VALUES (?,?)", (identity, int(time.time())))


def _clear_failed_attempts(identity: str):
    with _connect() as conn:
        conn.execute("DELETE FROM login_attempts WHERE identity_hash=?", (identity,))


def _pending_user():
    uid = session.get("pending_2fa_user_id")
    if not uid:
        return None
    with _connect() as conn:
        row = conn.execute("SELECT * FROM users WHERE id=? AND active=1", (uid,)).fetchone()
    return row


def _complete_login(user):
    session.clear()
    session.permanent = True
    session["user_id"] = user["id"]
    session["csrf_token"] = secrets.token_urlsafe(32)
    session["just_logged_in"] = True


def _make_recovery_codes(user_id: int):
    codes = [secrets.token_hex(8).upper() for _ in range(10)]
    with _connect() as conn:
        conn.execute("DELETE FROM recovery_codes WHERE user_id=?", (user_id,))
        conn.executemany(
            "INSERT INTO recovery_codes(user_id, code_hash) VALUES (?,?)",
            [(user_id, hashlib.sha256(code.encode()).hexdigest()) for code in codes]
        )
    return codes


def _valid_recovery_code(user_id: int, code: str) -> bool:
    digest = hashlib.sha256(code.strip().replace("-", "").upper().encode()).hexdigest()
    with _connect() as conn:
        row = conn.execute(
            "SELECT id FROM recovery_codes WHERE user_id=? AND code_hash=? AND used_at IS NULL",
            (user_id, digest)
        ).fetchone()
        if not row:
            return False
        conn.execute("UPDATE recovery_codes SET used_at=? WHERE id=?", (datetime.utcnow().isoformat(), row["id"]))
    return True


def _safe_next(value: str | None) -> str:
    if not value:
        return "/dashboard"
    parsed = urlparse(value)
    if parsed.scheme or parsed.netloc or not value.startswith("/") or value.startswith("//"):
        return "/dashboard"
    return value


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect("/dashboard")
    error = None
    if request.method == "POST":
        if not _check_csrf():
            abort(400, "Invalid form token. Refresh and try again.")
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        identity = _rate_key(username)
        if _is_rate_limited(identity):
            error = "Too many attempts. Wait 15 minutes before trying again."
        else:
            with _connect() as conn:
                user = conn.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
            valid = False
            if user and user["active"]:
                try:
                    valid = _pwd.verify(user["password_hash"], password)
                except (VerifyMismatchError, VerificationError):
                    valid = False
            if not valid:
                _record_failed_attempt(identity)
                error = "Invalid username or password."
            else:
                _clear_failed_attempts(identity)
                session.clear()
                session["pending_2fa_user_id"] = user["id"]
                session["pending_next"] = _safe_next(request.form.get("next"))
                if not user["totp_secret_enc"] or not user["totp_enabled"]:
                    return redirect(url_for("auth.setup_2fa"))
                return redirect(url_for("auth.verify_2fa"))
    return render_template("login.html", error=error, csrf_token=_csrf_token(), next_url=_safe_next(request.args.get("next")))


@auth_bp.route("/2fa/setup", methods=["GET", "POST"])
def setup_2fa():
    user = _pending_user()
    if not user:
        return redirect(url_for("auth.login"))
    if user["totp_enabled"]:
        return redirect(url_for("auth.verify_2fa"))
    secret = _decrypt(user["totp_secret_enc"])
    if not secret:
        secret = pyotp.random_base32()
        with _connect() as conn:
            conn.execute("UPDATE users SET totp_secret_enc=? WHERE id=?", (_encrypt(secret), user["id"]))
    uri = pyotp.TOTP(secret).provisioning_uri(name=user["username"], issuer_name="Car Accessories Professional")
    error = None
    identity = _rate_key(user["username"] + ":enrol")
    if _is_rate_limited(identity):
        error = "Too many setup attempts. Wait 15 minutes before trying again."
    elif request.method == "POST":
        if not _check_csrf():
            abort(400, "Invalid form token. Refresh and try again.")
        code = request.form.get("code", "").replace(" ", "")
        if pyotp.TOTP(secret).verify(code, valid_window=1):
            _clear_failed_attempts(identity)
            with _connect() as conn:
                conn.execute("UPDATE users SET totp_enabled=1 WHERE id=?", (user["id"],))
            recovery = _make_recovery_codes(user["id"])
            _complete_login(user)
            session["recovery_codes_once"] = recovery
            return redirect(url_for("auth.recovery_codes"))
        _record_failed_attempt(identity)
        error = "The code did not match. Check your authenticator app and try again."
    return render_template("setup_2fa.html", username=user["username"], secret=secret, uri=uri, error=error, csrf_token=_csrf_token())


@auth_bp.route("/2fa/verify", methods=["GET", "POST"])
def verify_2fa():
    user = _pending_user()
    if not user or not user["totp_enabled"]:
        return redirect(url_for("auth.login"))
    error = None
    identity = _rate_key(user["username"] + ":2fa")
    if _is_rate_limited(identity):
        error = "Too many verification attempts. Wait 15 minutes before trying again."
    elif request.method == "POST":
        if not _check_csrf():
            abort(400, "Invalid form token. Refresh and try again.")
        code = request.form.get("code", "").strip()
        secret = _decrypt(user["totp_secret_enc"])
        valid = bool(secret and pyotp.TOTP(secret).verify(code.replace(" ", ""), valid_window=1))
        if not valid:
            valid = _valid_recovery_code(user["id"], code)
        if valid:
            _clear_failed_attempts(identity)
            next_url = session.get("pending_next", "/dashboard")
            _complete_login(user)
            return redirect(_safe_next(next_url))
        _record_failed_attempt(identity)
        error = "Invalid authenticator code or recovery code."
    return render_template("verify_2fa.html", error=error, csrf_token=_csrf_token())


@auth_bp.route("/2fa/recovery-codes", methods=["GET"])
def recovery_codes():
    if not session.get("user_id"):
        return redirect(url_for("auth.login"))
    codes = session.pop("recovery_codes_once", None)
    if not codes:
        return redirect("/dashboard")
    return render_template("recovery_codes.html", codes=codes, csrf_token=_csrf_token())


@auth_bp.route("/logout", methods=["POST"])
def logout():
    if not _check_csrf():
        abort(400, "Invalid form token. Refresh and try again.")
    session.clear()
    return redirect(url_for("auth.login"))


@auth_bp.route("/admin/users", methods=["GET", "POST"])
def admin_users():
    if not getattr(g, "current_user", None) or g.current_user["role"] != "admin":
        abort(403)
    created_password = None
    message = None
    if request.method == "POST":
        if not _check_csrf():
            abort(400, "Invalid form token. Refresh and try again.")
        username = request.form.get("username", "").strip()
        if len(username) < 3 or len(username) > 40 or not all(c.isalnum() or c in "._-" for c in username):
            message = "Username must be 3–40 characters and contain only letters, numbers, dot, underscore or hyphen."
        else:
            created_password = secrets.token_urlsafe(15)
            try:
                with _connect() as conn:
                    conn.execute(
                        "INSERT INTO users(username,password_hash,role,active,created_at) VALUES (?,?, 'staff',1,?)",
                        (username, _pwd.hash(created_password), datetime.utcnow().isoformat())
                    )
                message = f"Staff account '{username}' created. Copy the temporary password now; it will not be shown again."
            except sqlite3.IntegrityError:
                created_password = None
                message = "That username already exists. Choose another username."
    with _connect() as conn:
        users = conn.execute("SELECT id, username, role, active, totp_enabled, created_at FROM users ORDER BY id").fetchall()
    return render_template("admin_users.html", users=users, created_password=created_password,
                           message=message, csrf_token=_csrf_token())


@auth_bp.post("/admin/users/<int:user_id>/toggle")
def toggle_user(user_id):
    if not getattr(g, "current_user", None) or g.current_user["role"] != "admin":
        abort(403)
    if not _check_csrf():
        abort(400, "Invalid form token. Refresh and try again.")
    if user_id == g.current_user["id"]:
        abort(400, "You cannot disable your own account.")
    with _connect() as conn:
        row = conn.execute("SELECT id, role, active FROM users WHERE id=?", (user_id,)).fetchone()
        if not row or row["role"] == "admin":
            abort(404)
        conn.execute("UPDATE users SET active=? WHERE id=?", (0 if row["active"] else 1, user_id))
    return redirect(url_for("auth.admin_users"))


def create_admin_account(username: str, password: str):
    """CLI helper. Call after init_auth(app, DATA_DIR). Returns TOTP setup details."""
    username = username.strip()
    if len(username) < 3 or len(password) < 14:
        raise ValueError("Admin username must be at least 3 characters and password at least 14 characters.")
    secret = pyotp.random_base32()
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO users(username,password_hash,role,active,totp_secret_enc,totp_enabled,created_at) VALUES (?,?, 'admin',1,?,0,?)",
            (username, _pwd.hash(password), _encrypt(secret), datetime.utcnow().isoformat())
        )
        user_id = cursor.lastrowid
    uri = pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name="Car Accessories Professional")
    return {"user_id": user_id, "username": username, "totp_secret": secret, "otpauth_uri": uri}
