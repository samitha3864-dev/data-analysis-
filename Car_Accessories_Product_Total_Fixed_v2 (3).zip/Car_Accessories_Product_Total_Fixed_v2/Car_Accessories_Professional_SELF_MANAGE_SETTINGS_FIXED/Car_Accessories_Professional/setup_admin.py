"""Run once to create the first administrator account."""
import getpass
from pathlib import Path
from flask import Flask
from auth import init_auth, create_admin_account

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
app = Flask(__name__)
init_auth(app, DATA_DIR)

with app.app_context():
    username = input("Admin username: ").strip()
    password = getpass.getpass("Admin password (minimum 14 characters): ")
    confirm = getpass.getpass("Confirm password: ")
    if password != confirm:
        raise SystemExit("Passwords do not match.")
    try:
        details = create_admin_account(username, password)
    except Exception as exc:
        raise SystemExit(f"Could not create admin: {exc}")
    print("\nADMIN ACCOUNT CREATED")
    print("Username:", details["username"])
    print("Authenticator secret:", details["totp_secret"])
    print("Add this account manually in Google Authenticator, Microsoft Authenticator, or 1Password:")
    print(details["otpauth_uri"])
    print("\nKeep the secret private. First login will ask you to verify a 6-digit code and enable 2FA.")
