CAR ACCESSORIES PROFESSIONAL — SECURE LOGIN SETUP

IMPORTANT
- This is an authentication add-on for the existing Flask app.
- Keep your existing data/website_data.json, data/products.xlsx, data/products_working.xlsx and all existing page templates.
- Copy the NEW files from this package into the project. Do not delete or replace your existing templates.
- The app creates a separate data/users.db and data/session_secret.key. These do not overwrite customer records.

1) FILES TO COPY
- Replace your current app.py with this package's app.py only if this package was built from your latest app_updated.py.
- Copy auth.py and setup_admin.py beside app.py.
- Copy the new login.html, setup_2fa.html, verify_2fa.html, recovery_codes.html, admin_users.html and _auth_base.html into your existing templates folder.
- Merge requirements.txt dependencies with your current file. Keep any extra dependencies used by your own app.

2) INSTALL
Open VS Code terminal in the project folder:
  python -m pip install -r requirements.txt

3) CREATE THE FIRST ADMIN (ONE TIME)
  python setup_admin.py
Enter an admin username and a strong password (at least 14 characters).
The command prints an authenticator setup key and otpauth URI. Add the account to Google Authenticator, Microsoft Authenticator, or another TOTP authenticator. Keep this secret private.

4) RUN LOCALLY
  python app.py
Open http://127.0.0.1:5000/login
Sign in with the admin credentials, complete 2FA setup, and save the recovery codes securely.

5) CREATE STAFF ACCOUNTS
After admin login, open:
  http://127.0.0.1:5000/admin/users
Create as many staff accounts as required. The generated temporary password is shown once. Give it privately to that staff member. Their first login forces authenticator setup and recovery-code generation.

STANDARD STAFF ACCESS
Allowed: customer entry (including adding a customer), customer details read-only, product catalogue viewing, dashboard.
Blocked: settings, product/category changes, imports, exports, analytics pages, customer edit/delete, clear Excel, staff management and all other routes not explicitly allowed.

SECURITY NOTES
- The app sets debug=False.
- The secret key is persisted in data/session_secret.key if FLASK_SECRET_KEY is not supplied. Do not delete this file while sessions are active; back it up securely.
- For production HTTPS hosting, set FLASK_SECRET_KEY to a long random secret and COOKIE_SECURE=1. Use HTTPS only. Do not expose the secret or users.db publicly.
- For local HTTP development, COOKIE_SECURE remains 0; do not use that setting on an HTTPS production deployment.
- Protect the data/ folder from public static serving and exclude users.db/session_secret.key from Git.
- Add this to .gitignore: data/users.db, data/users.db-shm, data/users.db-wal, data/session_secret.key, .env
- A TOTP authenticator code changes every 30 seconds. Recovery codes are single-use and shown only once after first enrolment.
- This package does not modify or migrate existing Excel/JSON customer data.

LOGOUT BUTTON SNIPPET
Add this inside the existing shared navbar/base template if you have one:
  {% if logged_in_user %}
    <span>{{ logged_in_user.username }} ({{ logged_in_user.role }})</span>
    {% if logged_in_user.role == 'admin' %}<a href="/admin/users">Staff Accounts</a>{% endif %}
    <form method="post" action="/logout" style="display:inline">
      <input type="hidden" name="csrf_token" value="{{ session.csrf_token }}">
      <button type="submit">Logout</button>
    </form>
  {% endif %}

If your templates use a custom navbar, add the snippet there. Do not paste it into every page if they extend a shared base template.
